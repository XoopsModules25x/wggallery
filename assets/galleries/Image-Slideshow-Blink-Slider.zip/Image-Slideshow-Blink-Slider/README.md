Blink Slider ver 1.1
Author: Fernando Mercadal https://fermercadal.github.io